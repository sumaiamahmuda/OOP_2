﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYM_MangmentSystem
{
    class Member:Person
    {
        private DateTime registrationdate;
        private DateTime billingdate;

        public DateTime Registrationdate
        {
            set { registrationdate = value; }
            get { return registrationdate; }
        }
        public DateTime Billingdate
        {
            set { billingdate = value; }
            get { return billingdate; }
        }

    }
}
