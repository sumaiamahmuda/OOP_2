﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM_MangmentSystem
{
    public partial class AccountForm : Form
    {
        Payment og;
        Member of;
        SqlRunClass aj;
        string ac;
        public AccountForm()
        {
            InitializeComponent();
            og = new Payment();
            of = new Member();
            aj = new SqlRunClass();
            ac = "select *from Account";
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            og.TrasactionId = int.Parse(textBoxTransactionid.Text);
            of.Id = int.Parse(textBoxId.Text);
            og.PaidAmount = textBoxPaidamount.Text;
            og.Date = DateTime.Parse(dateTimePickerDate.Text);
            string sqlText = @"insert into Account ([transactionid],[id],[paidamount],[date])
             values("+og.TrasactionId+"," + of.Id + ",'" + og.PaidAmount + "','" + og.Date + "')";
            aj.SqlExecute(sqlText);
            dataGridView1.DataSource = aj.showme(ac);

        }

        private void buttonSreach_Click(object sender, EventArgs e)
        {
            of.Id = int.Parse(textBoxId.Text);
            string cc = "select * from Account where id =" + of.Id + "";
            aj.SqlExecute(cc);
            dataGridView1.DataSource = aj.showme(cc);
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
           
            og.TrasactionId = int.Parse(textBoxTransactionid.Text);
            String sg = "Delete From Account where transactionid = " + og.TrasactionId + "";
            aj.SqlExecute(sg);
            MessageBox.Show("ITEM DELETE");
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            og.TrasactionId = int.Parse(textBoxTransactionid.Text);
            of.Id = int.Parse(textBoxId.Text);
            og.PaidAmount = textBoxPaidamount.Text;
            og.Date = DateTime.Parse(dateTimePickerDate.Text);
            string gg = "update Account set id=" + of.Id + ",paidamount='" + og.PaidAmount + "',date='" + og.Date + "'where transactionid=" + og.TrasactionId + "";
            aj.SqlExecute(gg);
            MessageBox.Show("UPDATED");
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void AccountForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = aj.showme(ac);
        }
    }
}
