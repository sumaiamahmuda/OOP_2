﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace GYM_MangmentSystem
{
    public partial class MemberForm : Form
    {
        Member ob1 ;
        MembershipCatagory od;
        Batch or;
        FeePlan ol;
        string ac = "select * from Member";
        SqlRunClass aj;
        public MemberForm()
        {
            InitializeComponent();
            ob1 = new Member();
            aj = new SqlRunClass();
            od = new MembershipCatagory();
            or = new Batch();
            ol = new FeePlan();
            
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            ob1.Id = int.Parse(textBoxId.Text);
            ob1.lastName = textBoxLastName.Text;
            ob1.firstName = textBoxFirstName.Text;
            ob1.MobileNo = textBoxMobileNo.Text;
            ob1.Dateofbirth = DateTime.Parse(dateTimePickerDateofbirth.Text);
            ob1.Gender = textBoxGender.Text;
            ob1.Email = textBoxEmail.Text;
            ob1.Registrationdate = DateTime.Parse(dateTimePickerRegistrationdate.Text);
            od.Name = textBoxMembershipName.Text;
            or.Name = textBoxBatch.Text;
            ol.Name = textBoxFeePlan.Text;
            string sqlText = @"insert into Member([id]
      ,[firstname]
      ,[lastname]
      ,[gender]
      ,[dateofbirth]
      ,[email]
      ,[mobilenumber]
      ,[registrationdate]
      ,[membershipcategoryname],[batchname],[feeplanname])
          values(" + ob1.Id + ", '" + ob1.lastName + "', '" + ob1.firstName + "','" + ob1.Gender + "' ,'" + ob1.Dateofbirth + "'," +
          "'" + ob1.Email + "','" + ob1.MobileNo + "','"+ob1.Registrationdate+"','"+od.Name+"','"+ or.Name +"','"+ ol.Name+"')";
            aj.SqlExecute(sqlText);
            dataGridView1.DataSource = aj.showme(ac);
        }
        private void buttonSearch_Click(object sender, EventArgs e)
        {
            ob1.Id = int.Parse(textBoxId.Text);
            string cc = "select * from Member where id =" + ob1.Id + "";
            aj.SqlExecute(cc);
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            ob1.Id = int.Parse(textBoxId.Text);
            String sg = "Delete From Member where id = " + ob1.Id + "";
            aj.SqlExecute(sg);
            MessageBox.Show("ITEM DELETE");
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            ob1.Id = int.Parse(textBoxId.Text);
            ob1.lastName = textBoxLastName.Text;
            ob1.firstName = textBoxFirstName.Text;
            ob1.MobileNo = textBoxMobileNo.Text;
            ob1.Dateofbirth = DateTime.Parse(dateTimePickerDateofbirth.Text);
            ob1.Email = textBoxEmail.Text;
            ob1.Registrationdate = DateTime.Parse(dateTimePickerRegistrationdate.Text);
            od.Name = textBoxMembershipName.Text;
            or.Name = textBoxBatch.Text;
            ol.Name = textBoxFeePlan.Text;
            string gg = "update Member set lastname='" + ob1.lastName + "',firstname='" + ob1.firstName + "',mobilenumber='" + ob1.MobileNo + "'," +
            " dateofbirth='" + ob1.Dateofbirth + "',email = '" + ob1.Email + "'," +
         " registrationdate = '" + ob1.Registrationdate + "',membershipcategoryname='" + od.Name + "',batchname='" + or.Name + "',feeplanname='" + ol.Name + "' where id =" + ob1.Id + " ";
            aj.SqlExecute(gg);
            MessageBox.Show("UPDATED");
            dataGridView1.DataSource = aj.showme(ac);
        }

        private void MemberForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = aj.showme(ac);
        }
    }
}
