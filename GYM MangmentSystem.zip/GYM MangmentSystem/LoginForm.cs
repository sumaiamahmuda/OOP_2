﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM_MangmentSystem
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            Login ob = new Login();
            ob.Username = textBoxUsername.Text;
            ob.Password = textBoxPassword.Text;
            if (ob.Username == "zubaida" & ob.Password == "12345")
            {
                this.Hide();
                HomepageForm objHomeForm = new HomepageForm();

                objHomeForm.Show();
            }
            else { MessageBox.Show("Username or Password not recognised"); }
        }
    }
}
