﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM_MangmentSystem
{
    public partial class HomepageForm : Form
    {
        public HomepageForm()
        {
            InitializeComponent();
        }

        private void buttonMemberregistration_Click(object sender, EventArgs e)
        {
            MemberForm objMemberForm = new MemberForm();

            objMemberForm.Show();
        }

        private void buttonEmployeeregistration_Click(object sender, EventArgs e)
        {
            EmployeeForm obj = new EmployeeForm();

            obj.Show();
        }

        private void buttonFeeplan_Click(object sender, EventArgs e)
        {
            FeePlanForm obj1 = new FeePlanForm();

            obj1.Show();
        }

        private void buttonBatch_Click(object sender, EventArgs e)
        {
            BatchForm obj3 = new BatchForm();

            obj3.Show();
        }

        private void buttonMembershipcatagory_Click(object sender, EventArgs e)
        {
            MembershipCategoryForm obj4 = new MembershipCategoryForm();

            obj4.Show();
        }

        private void buttonPayment_Click(object sender, EventArgs e)
        {
           AccountForm obj5 = new AccountForm();

            obj5.Show();
        }

        private void buttonLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm objloginForm = new LoginForm();

            objloginForm.Show();
        }
    }
}
