﻿
namespace GYM_MangmentSystem
{
    partial class HomepageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.buttonMemberregistration = new System.Windows.Forms.Button();
            this.buttonEmployeeregistration = new System.Windows.Forms.Button();
            this.buttonFeeplan = new System.Windows.Forms.Button();
            this.buttonBatch = new System.Windows.Forms.Button();
            this.buttonMembershipcatagory = new System.Windows.Forms.Button();
            this.buttonPayment = new System.Windows.Forms.Button();
            this.buttonLogout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(533, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Home Page";
            // 
            // buttonMemberregistration
            // 
            this.buttonMemberregistration.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonMemberregistration.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMemberregistration.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonMemberregistration.Location = new System.Drawing.Point(12, 97);
            this.buttonMemberregistration.Name = "buttonMemberregistration";
            this.buttonMemberregistration.Size = new System.Drawing.Size(202, 39);
            this.buttonMemberregistration.TabIndex = 1;
            this.buttonMemberregistration.Text = "Member Registration";
            this.buttonMemberregistration.UseVisualStyleBackColor = false;
            this.buttonMemberregistration.Click += new System.EventHandler(this.buttonMemberregistration_Click);
            // 
            // buttonEmployeeregistration
            // 
            this.buttonEmployeeregistration.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonEmployeeregistration.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEmployeeregistration.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonEmployeeregistration.Location = new System.Drawing.Point(234, 97);
            this.buttonEmployeeregistration.Name = "buttonEmployeeregistration";
            this.buttonEmployeeregistration.Size = new System.Drawing.Size(202, 39);
            this.buttonEmployeeregistration.TabIndex = 2;
            this.buttonEmployeeregistration.Text = "Employee Registration";
            this.buttonEmployeeregistration.UseVisualStyleBackColor = false;
            this.buttonEmployeeregistration.Click += new System.EventHandler(this.buttonEmployeeregistration_Click);
            // 
            // buttonFeeplan
            // 
            this.buttonFeeplan.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonFeeplan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFeeplan.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonFeeplan.Location = new System.Drawing.Point(459, 97);
            this.buttonFeeplan.Name = "buttonFeeplan";
            this.buttonFeeplan.Size = new System.Drawing.Size(202, 39);
            this.buttonFeeplan.TabIndex = 3;
            this.buttonFeeplan.Text = "Fee Plan";
            this.buttonFeeplan.UseVisualStyleBackColor = false;
            this.buttonFeeplan.Click += new System.EventHandler(this.buttonFeeplan_Click);
            // 
            // buttonBatch
            // 
            this.buttonBatch.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonBatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBatch.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonBatch.Location = new System.Drawing.Point(687, 97);
            this.buttonBatch.Name = "buttonBatch";
            this.buttonBatch.Size = new System.Drawing.Size(202, 39);
            this.buttonBatch.TabIndex = 4;
            this.buttonBatch.Text = "Batch";
            this.buttonBatch.UseVisualStyleBackColor = false;
            this.buttonBatch.Click += new System.EventHandler(this.buttonBatch_Click);
            // 
            // buttonMembershipcatagory
            // 
            this.buttonMembershipcatagory.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonMembershipcatagory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMembershipcatagory.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonMembershipcatagory.Location = new System.Drawing.Point(895, 94);
            this.buttonMembershipcatagory.Name = "buttonMembershipcatagory";
            this.buttonMembershipcatagory.Size = new System.Drawing.Size(202, 42);
            this.buttonMembershipcatagory.TabIndex = 5;
            this.buttonMembershipcatagory.Text = "Membership Catagory";
            this.buttonMembershipcatagory.UseVisualStyleBackColor = false;
            this.buttonMembershipcatagory.Click += new System.EventHandler(this.buttonMembershipcatagory_Click);
            // 
            // buttonPayment
            // 
            this.buttonPayment.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPayment.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonPayment.Location = new System.Drawing.Point(1121, 97);
            this.buttonPayment.Name = "buttonPayment";
            this.buttonPayment.Size = new System.Drawing.Size(202, 39);
            this.buttonPayment.TabIndex = 6;
            this.buttonPayment.Text = "Payment";
            this.buttonPayment.UseVisualStyleBackColor = false;
            this.buttonPayment.Click += new System.EventHandler(this.buttonPayment_Click);
            // 
            // buttonLogout
            // 
            this.buttonLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLogout.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonLogout.Location = new System.Drawing.Point(1121, 23);
            this.buttonLogout.Name = "buttonLogout";
            this.buttonLogout.Size = new System.Drawing.Size(202, 39);
            this.buttonLogout.TabIndex = 7;
            this.buttonLogout.Text = "Log Out";
            this.buttonLogout.UseVisualStyleBackColor = false;
            this.buttonLogout.Click += new System.EventHandler(this.buttonLogout_Click);
            // 
            // HomepageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1362, 443);
            this.Controls.Add(this.buttonLogout);
            this.Controls.Add(this.buttonPayment);
            this.Controls.Add(this.buttonMembershipcatagory);
            this.Controls.Add(this.buttonBatch);
            this.Controls.Add(this.buttonFeeplan);
            this.Controls.Add(this.buttonEmployeeregistration);
            this.Controls.Add(this.buttonMemberregistration);
            this.Controls.Add(this.label1);
            this.Name = "HomepageForm";
            this.Text = "HomepageForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonMemberregistration;
        private System.Windows.Forms.Button buttonEmployeeregistration;
        private System.Windows.Forms.Button buttonFeeplan;
        private System.Windows.Forms.Button buttonBatch;
        private System.Windows.Forms.Button buttonMembershipcatagory;
        private System.Windows.Forms.Button buttonPayment;
        private System.Windows.Forms.Button buttonLogout;
    }
}