﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYM_MangmentSystem
{
    class Payment
    {
        private int transactionid;
        private string paidamount;
        private DateTime date;
        public string PaidAmount
        {
            set { paidamount = value; }
            get { return paidamount; }
        }
        public int TrasactionId
        {
            set { transactionid = value; }
            get { return transactionid; }
        }
        public DateTime Date
        {
            set { date = value; }
            get { return date; }
        }
    }
}
