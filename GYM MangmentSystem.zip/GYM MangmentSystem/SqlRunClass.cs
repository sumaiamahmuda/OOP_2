﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace GYM_MangmentSystem
{
    class SqlRunClass
    {
        SqlConnection connectionString = new SqlConnection("Data Source=DESKTOP-72P5PK0;Initial Catalog=Gymmangement;User ID=sa;Password=admin@123456");
        
        public void SqlExecute(string s)
        {
            connectionString.Open();
            SqlCommand cmd = new SqlCommand(s, connectionString);
            cmd.ExecuteNonQuery();
            connectionString.Close();
            
        }
        public DataTable showme(string ac)
        {
            SqlCommand sc = new SqlCommand(ac, connectionString);
            SqlDataAdapter sA = new SqlDataAdapter(sc);
            DataTable dt = new DataTable();
            sA.Fill(dt); 
            return dt;
            
        }
    }
}
